package it.proietto.battleShips.ships;

public class FieldNotInilializedException extends Exception {

    public FieldNotInilializedException(String errorMessage) {
        super(errorMessage);
    }
}
